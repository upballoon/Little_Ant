// Auto-generated. Do not edit!

// (in-package driverless_actions.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class DoDriverlessTaskGoal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.task = null;
      this.type = null;
      this.target_pose = null;
      this.target_path = null;
      this.path_resolution = null;
      this.expect_speed = null;
      this.roadnet_file = null;
      this.path_filp = null;
    }
    else {
      if (initObj.hasOwnProperty('task')) {
        this.task = initObj.task
      }
      else {
        this.task = 0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('target_pose')) {
        this.target_pose = initObj.target_pose
      }
      else {
        this.target_pose = new geometry_msgs.msg.Pose2D();
      }
      if (initObj.hasOwnProperty('target_path')) {
        this.target_path = initObj.target_path
      }
      else {
        this.target_path = [];
      }
      if (initObj.hasOwnProperty('path_resolution')) {
        this.path_resolution = initObj.path_resolution
      }
      else {
        this.path_resolution = 0.0;
      }
      if (initObj.hasOwnProperty('expect_speed')) {
        this.expect_speed = initObj.expect_speed
      }
      else {
        this.expect_speed = 0.0;
      }
      if (initObj.hasOwnProperty('roadnet_file')) {
        this.roadnet_file = initObj.roadnet_file
      }
      else {
        this.roadnet_file = '';
      }
      if (initObj.hasOwnProperty('path_filp')) {
        this.path_filp = initObj.path_filp
      }
      else {
        this.path_filp = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DoDriverlessTaskGoal
    // Serialize message field [task]
    bufferOffset = _serializer.uint8(obj.task, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [target_pose]
    bufferOffset = geometry_msgs.msg.Pose2D.serialize(obj.target_pose, buffer, bufferOffset);
    // Serialize message field [target_path]
    // Serialize the length for message field [target_path]
    bufferOffset = _serializer.uint32(obj.target_path.length, buffer, bufferOffset);
    obj.target_path.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose2D.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [path_resolution]
    bufferOffset = _serializer.float32(obj.path_resolution, buffer, bufferOffset);
    // Serialize message field [expect_speed]
    bufferOffset = _serializer.float32(obj.expect_speed, buffer, bufferOffset);
    // Serialize message field [roadnet_file]
    bufferOffset = _serializer.string(obj.roadnet_file, buffer, bufferOffset);
    // Serialize message field [path_filp]
    bufferOffset = _serializer.bool(obj.path_filp, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DoDriverlessTaskGoal
    let len;
    let data = new DoDriverlessTaskGoal(null);
    // Deserialize message field [task]
    data.task = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [target_pose]
    data.target_pose = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset);
    // Deserialize message field [target_path]
    // Deserialize array length for message field [target_path]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.target_path = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.target_path[i] = geometry_msgs.msg.Pose2D.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [path_resolution]
    data.path_resolution = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [expect_speed]
    data.expect_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [roadnet_file]
    data.roadnet_file = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [path_filp]
    data.path_filp = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 24 * object.target_path.length;
    length += object.roadnet_file.length;
    return length + 43;
  }

  static datatype() {
    // Returns string type for a message object
    return 'driverless_actions/DoDriverlessTaskGoal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '19f66abfc85b30c39ccf7379f5d934fc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======
    #Define the goal
    
    uint8 DRIVE_TASK   = 0
    uint8 REVERSE_TASK = 1
    uint8 task
    
    uint8 POSE_TYPE = 1
    uint8 PATH_TYPE = 2
    uint8 FILE_TYPE = 3
    uint8 type
    
    geometry_msgs/Pose2D   target_pose
    geometry_msgs/Pose2D[] target_path
    
    float32 path_resolution
    float32 expect_speed
    string  roadnet_file
    bool    path_filp
    
    
    ================================================================================
    MSG: geometry_msgs/Pose2D
    # Deprecated
    # Please use the full 3D pose.
    
    # In general our recommendation is to use a full 3D representation of everything and for 2D specific applications make the appropriate projections into the plane for their calculations but optimally will preserve the 3D information during processing.
    
    # If we have parallel copies of 2D datatypes every UI and other pipeline will end up needing to have dual interfaces to plot everything. And you will end up with not being able to use 3D tools for 2D use cases even if they're completely valid, as you'd have to reimplement it with different inputs and outputs. It's not particularly hard to plot the 2D pose or compute the yaw error for the Pose message and there are already tools and libraries that can do this for you.
    
    
    # This expresses a position and orientation on a 2D manifold.
    
    float64 x
    float64 y
    float64 theta
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DoDriverlessTaskGoal(null);
    if (msg.task !== undefined) {
      resolved.task = msg.task;
    }
    else {
      resolved.task = 0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.target_pose !== undefined) {
      resolved.target_pose = geometry_msgs.msg.Pose2D.Resolve(msg.target_pose)
    }
    else {
      resolved.target_pose = new geometry_msgs.msg.Pose2D()
    }

    if (msg.target_path !== undefined) {
      resolved.target_path = new Array(msg.target_path.length);
      for (let i = 0; i < resolved.target_path.length; ++i) {
        resolved.target_path[i] = geometry_msgs.msg.Pose2D.Resolve(msg.target_path[i]);
      }
    }
    else {
      resolved.target_path = []
    }

    if (msg.path_resolution !== undefined) {
      resolved.path_resolution = msg.path_resolution;
    }
    else {
      resolved.path_resolution = 0.0
    }

    if (msg.expect_speed !== undefined) {
      resolved.expect_speed = msg.expect_speed;
    }
    else {
      resolved.expect_speed = 0.0
    }

    if (msg.roadnet_file !== undefined) {
      resolved.roadnet_file = msg.roadnet_file;
    }
    else {
      resolved.roadnet_file = ''
    }

    if (msg.path_filp !== undefined) {
      resolved.path_filp = msg.path_filp;
    }
    else {
      resolved.path_filp = false
    }

    return resolved;
    }
};

// Constants for message
DoDriverlessTaskGoal.Constants = {
  DRIVE_TASK: 0,
  REVERSE_TASK: 1,
  POSE_TYPE: 1,
  PATH_TYPE: 2,
  FILE_TYPE: 3,
}

module.exports = DoDriverlessTaskGoal;

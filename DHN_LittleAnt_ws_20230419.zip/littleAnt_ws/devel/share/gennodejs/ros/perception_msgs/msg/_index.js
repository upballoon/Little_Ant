
"use strict";

let ObstacleArray = require('./ObstacleArray.js');
let Obstacle = require('./Obstacle.js');

module.exports = {
  ObstacleArray: ObstacleArray,
  Obstacle: Obstacle,
};

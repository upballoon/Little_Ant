
"use strict";

let OBU_fusion = require('./OBU_fusion.js');

module.exports = {
  OBU_fusion: OBU_fusion,
};

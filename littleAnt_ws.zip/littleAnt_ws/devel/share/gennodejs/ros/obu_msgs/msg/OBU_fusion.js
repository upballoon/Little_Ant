// Auto-generated. Do not edit!

// (in-package obu_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class OBU_fusion {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.light_state = null;
      this.light_remain_time = null;
      this.light_jd = null;
      this.light_wd = null;
      this.light_x = null;
      this.light_y = null;
      this.obu_jd = null;
      this.obu_wd = null;
      this.obu_angle = null;
      this.obu_x = null;
      this.obu_y = null;
      this.obu_angle_rad = null;
      this.event_jd = null;
      this.event_wd = null;
      this.event_x = null;
      this.event_y = null;
      this.event_length = null;
      this.event_radius = null;
      this.park_jd = null;
      this.park_wd = null;
      this.park_x = null;
      this.park_y = null;
      this.emergency_car_jd = null;
      this.emergency_car_wd = null;
      this.emergency_car_x = null;
      this.emergency_car_y = null;
      this.emergency_car_is_near = null;
      this.terminal_jd = null;
      this.terminal_wd = null;
      this.terminal_x = null;
      this.terminal_y = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('light_state')) {
        this.light_state = initObj.light_state
      }
      else {
        this.light_state = 0;
      }
      if (initObj.hasOwnProperty('light_remain_time')) {
        this.light_remain_time = initObj.light_remain_time
      }
      else {
        this.light_remain_time = 0;
      }
      if (initObj.hasOwnProperty('light_jd')) {
        this.light_jd = initObj.light_jd
      }
      else {
        this.light_jd = 0.0;
      }
      if (initObj.hasOwnProperty('light_wd')) {
        this.light_wd = initObj.light_wd
      }
      else {
        this.light_wd = 0.0;
      }
      if (initObj.hasOwnProperty('light_x')) {
        this.light_x = initObj.light_x
      }
      else {
        this.light_x = 0.0;
      }
      if (initObj.hasOwnProperty('light_y')) {
        this.light_y = initObj.light_y
      }
      else {
        this.light_y = 0.0;
      }
      if (initObj.hasOwnProperty('obu_jd')) {
        this.obu_jd = initObj.obu_jd
      }
      else {
        this.obu_jd = 0.0;
      }
      if (initObj.hasOwnProperty('obu_wd')) {
        this.obu_wd = initObj.obu_wd
      }
      else {
        this.obu_wd = 0.0;
      }
      if (initObj.hasOwnProperty('obu_angle')) {
        this.obu_angle = initObj.obu_angle
      }
      else {
        this.obu_angle = 0.0;
      }
      if (initObj.hasOwnProperty('obu_x')) {
        this.obu_x = initObj.obu_x
      }
      else {
        this.obu_x = 0.0;
      }
      if (initObj.hasOwnProperty('obu_y')) {
        this.obu_y = initObj.obu_y
      }
      else {
        this.obu_y = 0.0;
      }
      if (initObj.hasOwnProperty('obu_angle_rad')) {
        this.obu_angle_rad = initObj.obu_angle_rad
      }
      else {
        this.obu_angle_rad = 0.0;
      }
      if (initObj.hasOwnProperty('event_jd')) {
        this.event_jd = initObj.event_jd
      }
      else {
        this.event_jd = 0.0;
      }
      if (initObj.hasOwnProperty('event_wd')) {
        this.event_wd = initObj.event_wd
      }
      else {
        this.event_wd = 0.0;
      }
      if (initObj.hasOwnProperty('event_x')) {
        this.event_x = initObj.event_x
      }
      else {
        this.event_x = 0.0;
      }
      if (initObj.hasOwnProperty('event_y')) {
        this.event_y = initObj.event_y
      }
      else {
        this.event_y = 0.0;
      }
      if (initObj.hasOwnProperty('event_length')) {
        this.event_length = initObj.event_length
      }
      else {
        this.event_length = 0.0;
      }
      if (initObj.hasOwnProperty('event_radius')) {
        this.event_radius = initObj.event_radius
      }
      else {
        this.event_radius = 0.0;
      }
      if (initObj.hasOwnProperty('park_jd')) {
        this.park_jd = initObj.park_jd
      }
      else {
        this.park_jd = 0.0;
      }
      if (initObj.hasOwnProperty('park_wd')) {
        this.park_wd = initObj.park_wd
      }
      else {
        this.park_wd = 0.0;
      }
      if (initObj.hasOwnProperty('park_x')) {
        this.park_x = initObj.park_x
      }
      else {
        this.park_x = 0.0;
      }
      if (initObj.hasOwnProperty('park_y')) {
        this.park_y = initObj.park_y
      }
      else {
        this.park_y = 0.0;
      }
      if (initObj.hasOwnProperty('emergency_car_jd')) {
        this.emergency_car_jd = initObj.emergency_car_jd
      }
      else {
        this.emergency_car_jd = 0.0;
      }
      if (initObj.hasOwnProperty('emergency_car_wd')) {
        this.emergency_car_wd = initObj.emergency_car_wd
      }
      else {
        this.emergency_car_wd = 0.0;
      }
      if (initObj.hasOwnProperty('emergency_car_x')) {
        this.emergency_car_x = initObj.emergency_car_x
      }
      else {
        this.emergency_car_x = 0.0;
      }
      if (initObj.hasOwnProperty('emergency_car_y')) {
        this.emergency_car_y = initObj.emergency_car_y
      }
      else {
        this.emergency_car_y = 0.0;
      }
      if (initObj.hasOwnProperty('emergency_car_is_near')) {
        this.emergency_car_is_near = initObj.emergency_car_is_near
      }
      else {
        this.emergency_car_is_near = 0;
      }
      if (initObj.hasOwnProperty('terminal_jd')) {
        this.terminal_jd = initObj.terminal_jd
      }
      else {
        this.terminal_jd = 0.0;
      }
      if (initObj.hasOwnProperty('terminal_wd')) {
        this.terminal_wd = initObj.terminal_wd
      }
      else {
        this.terminal_wd = 0.0;
      }
      if (initObj.hasOwnProperty('terminal_x')) {
        this.terminal_x = initObj.terminal_x
      }
      else {
        this.terminal_x = 0.0;
      }
      if (initObj.hasOwnProperty('terminal_y')) {
        this.terminal_y = initObj.terminal_y
      }
      else {
        this.terminal_y = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type OBU_fusion
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [light_state]
    bufferOffset = _serializer.int32(obj.light_state, buffer, bufferOffset);
    // Serialize message field [light_remain_time]
    bufferOffset = _serializer.int32(obj.light_remain_time, buffer, bufferOffset);
    // Serialize message field [light_jd]
    bufferOffset = _serializer.float64(obj.light_jd, buffer, bufferOffset);
    // Serialize message field [light_wd]
    bufferOffset = _serializer.float64(obj.light_wd, buffer, bufferOffset);
    // Serialize message field [light_x]
    bufferOffset = _serializer.float64(obj.light_x, buffer, bufferOffset);
    // Serialize message field [light_y]
    bufferOffset = _serializer.float64(obj.light_y, buffer, bufferOffset);
    // Serialize message field [obu_jd]
    bufferOffset = _serializer.float64(obj.obu_jd, buffer, bufferOffset);
    // Serialize message field [obu_wd]
    bufferOffset = _serializer.float64(obj.obu_wd, buffer, bufferOffset);
    // Serialize message field [obu_angle]
    bufferOffset = _serializer.float64(obj.obu_angle, buffer, bufferOffset);
    // Serialize message field [obu_x]
    bufferOffset = _serializer.float64(obj.obu_x, buffer, bufferOffset);
    // Serialize message field [obu_y]
    bufferOffset = _serializer.float64(obj.obu_y, buffer, bufferOffset);
    // Serialize message field [obu_angle_rad]
    bufferOffset = _serializer.float64(obj.obu_angle_rad, buffer, bufferOffset);
    // Serialize message field [event_jd]
    bufferOffset = _serializer.float64(obj.event_jd, buffer, bufferOffset);
    // Serialize message field [event_wd]
    bufferOffset = _serializer.float64(obj.event_wd, buffer, bufferOffset);
    // Serialize message field [event_x]
    bufferOffset = _serializer.float64(obj.event_x, buffer, bufferOffset);
    // Serialize message field [event_y]
    bufferOffset = _serializer.float64(obj.event_y, buffer, bufferOffset);
    // Serialize message field [event_length]
    bufferOffset = _serializer.float64(obj.event_length, buffer, bufferOffset);
    // Serialize message field [event_radius]
    bufferOffset = _serializer.float64(obj.event_radius, buffer, bufferOffset);
    // Serialize message field [park_jd]
    bufferOffset = _serializer.float64(obj.park_jd, buffer, bufferOffset);
    // Serialize message field [park_wd]
    bufferOffset = _serializer.float64(obj.park_wd, buffer, bufferOffset);
    // Serialize message field [park_x]
    bufferOffset = _serializer.float64(obj.park_x, buffer, bufferOffset);
    // Serialize message field [park_y]
    bufferOffset = _serializer.float64(obj.park_y, buffer, bufferOffset);
    // Serialize message field [emergency_car_jd]
    bufferOffset = _serializer.float64(obj.emergency_car_jd, buffer, bufferOffset);
    // Serialize message field [emergency_car_wd]
    bufferOffset = _serializer.float64(obj.emergency_car_wd, buffer, bufferOffset);
    // Serialize message field [emergency_car_x]
    bufferOffset = _serializer.float64(obj.emergency_car_x, buffer, bufferOffset);
    // Serialize message field [emergency_car_y]
    bufferOffset = _serializer.float64(obj.emergency_car_y, buffer, bufferOffset);
    // Serialize message field [emergency_car_is_near]
    bufferOffset = _serializer.int32(obj.emergency_car_is_near, buffer, bufferOffset);
    // Serialize message field [terminal_jd]
    bufferOffset = _serializer.float64(obj.terminal_jd, buffer, bufferOffset);
    // Serialize message field [terminal_wd]
    bufferOffset = _serializer.float64(obj.terminal_wd, buffer, bufferOffset);
    // Serialize message field [terminal_x]
    bufferOffset = _serializer.float64(obj.terminal_x, buffer, bufferOffset);
    // Serialize message field [terminal_y]
    bufferOffset = _serializer.float64(obj.terminal_y, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type OBU_fusion
    let len;
    let data = new OBU_fusion(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [light_state]
    data.light_state = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [light_remain_time]
    data.light_remain_time = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [light_jd]
    data.light_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [light_wd]
    data.light_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [light_x]
    data.light_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [light_y]
    data.light_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_jd]
    data.obu_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_wd]
    data.obu_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_angle]
    data.obu_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_x]
    data.obu_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_y]
    data.obu_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [obu_angle_rad]
    data.obu_angle_rad = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_jd]
    data.event_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_wd]
    data.event_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_x]
    data.event_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_y]
    data.event_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_length]
    data.event_length = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [event_radius]
    data.event_radius = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [park_jd]
    data.park_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [park_wd]
    data.park_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [park_x]
    data.park_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [park_y]
    data.park_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [emergency_car_jd]
    data.emergency_car_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [emergency_car_wd]
    data.emergency_car_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [emergency_car_x]
    data.emergency_car_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [emergency_car_y]
    data.emergency_car_y = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [emergency_car_is_near]
    data.emergency_car_is_near = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [terminal_jd]
    data.terminal_jd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [terminal_wd]
    data.terminal_wd = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [terminal_x]
    data.terminal_x = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [terminal_y]
    data.terminal_y = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 236;
  }

  static datatype() {
    // Returns string type for a message object
    return 'obu_msgs/OBU_fusion';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '93d8d4cceb56956a2ec1724624ae62cb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    std_msgs/Header header
    
    # Add light information here.
    int32 light_state
    int32 light_remain_time
    float64 light_jd
    float64 light_wd
    float64 light_x
    float64 light_y
    
    # Add ego vehicle information here.
    float64 obu_jd
    float64 obu_wd
    float64 obu_angle
    float64 obu_x
    float64 obu_y
    float64 obu_angle_rad
    
    # Add obstacle information here.
    float64 event_jd
    float64 event_wd
    float64 event_x
    float64 event_y
    float64 event_length
    float64 event_radius
    
    # Add park information here.
    float64 park_jd
    float64 park_wd
    float64 park_x
    float64 park_y
    
    # Add emergency car here.
    float64 emergency_car_jd
    float64 emergency_car_wd
    float64 emergency_car_x
    float64 emergency_car_y
    int32 emergency_car_is_near
    
    # Add terminal point here.
    float64 terminal_jd
    float64 terminal_wd
    float64 terminal_x
    float64 terminal_y
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new OBU_fusion(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.light_state !== undefined) {
      resolved.light_state = msg.light_state;
    }
    else {
      resolved.light_state = 0
    }

    if (msg.light_remain_time !== undefined) {
      resolved.light_remain_time = msg.light_remain_time;
    }
    else {
      resolved.light_remain_time = 0
    }

    if (msg.light_jd !== undefined) {
      resolved.light_jd = msg.light_jd;
    }
    else {
      resolved.light_jd = 0.0
    }

    if (msg.light_wd !== undefined) {
      resolved.light_wd = msg.light_wd;
    }
    else {
      resolved.light_wd = 0.0
    }

    if (msg.light_x !== undefined) {
      resolved.light_x = msg.light_x;
    }
    else {
      resolved.light_x = 0.0
    }

    if (msg.light_y !== undefined) {
      resolved.light_y = msg.light_y;
    }
    else {
      resolved.light_y = 0.0
    }

    if (msg.obu_jd !== undefined) {
      resolved.obu_jd = msg.obu_jd;
    }
    else {
      resolved.obu_jd = 0.0
    }

    if (msg.obu_wd !== undefined) {
      resolved.obu_wd = msg.obu_wd;
    }
    else {
      resolved.obu_wd = 0.0
    }

    if (msg.obu_angle !== undefined) {
      resolved.obu_angle = msg.obu_angle;
    }
    else {
      resolved.obu_angle = 0.0
    }

    if (msg.obu_x !== undefined) {
      resolved.obu_x = msg.obu_x;
    }
    else {
      resolved.obu_x = 0.0
    }

    if (msg.obu_y !== undefined) {
      resolved.obu_y = msg.obu_y;
    }
    else {
      resolved.obu_y = 0.0
    }

    if (msg.obu_angle_rad !== undefined) {
      resolved.obu_angle_rad = msg.obu_angle_rad;
    }
    else {
      resolved.obu_angle_rad = 0.0
    }

    if (msg.event_jd !== undefined) {
      resolved.event_jd = msg.event_jd;
    }
    else {
      resolved.event_jd = 0.0
    }

    if (msg.event_wd !== undefined) {
      resolved.event_wd = msg.event_wd;
    }
    else {
      resolved.event_wd = 0.0
    }

    if (msg.event_x !== undefined) {
      resolved.event_x = msg.event_x;
    }
    else {
      resolved.event_x = 0.0
    }

    if (msg.event_y !== undefined) {
      resolved.event_y = msg.event_y;
    }
    else {
      resolved.event_y = 0.0
    }

    if (msg.event_length !== undefined) {
      resolved.event_length = msg.event_length;
    }
    else {
      resolved.event_length = 0.0
    }

    if (msg.event_radius !== undefined) {
      resolved.event_radius = msg.event_radius;
    }
    else {
      resolved.event_radius = 0.0
    }

    if (msg.park_jd !== undefined) {
      resolved.park_jd = msg.park_jd;
    }
    else {
      resolved.park_jd = 0.0
    }

    if (msg.park_wd !== undefined) {
      resolved.park_wd = msg.park_wd;
    }
    else {
      resolved.park_wd = 0.0
    }

    if (msg.park_x !== undefined) {
      resolved.park_x = msg.park_x;
    }
    else {
      resolved.park_x = 0.0
    }

    if (msg.park_y !== undefined) {
      resolved.park_y = msg.park_y;
    }
    else {
      resolved.park_y = 0.0
    }

    if (msg.emergency_car_jd !== undefined) {
      resolved.emergency_car_jd = msg.emergency_car_jd;
    }
    else {
      resolved.emergency_car_jd = 0.0
    }

    if (msg.emergency_car_wd !== undefined) {
      resolved.emergency_car_wd = msg.emergency_car_wd;
    }
    else {
      resolved.emergency_car_wd = 0.0
    }

    if (msg.emergency_car_x !== undefined) {
      resolved.emergency_car_x = msg.emergency_car_x;
    }
    else {
      resolved.emergency_car_x = 0.0
    }

    if (msg.emergency_car_y !== undefined) {
      resolved.emergency_car_y = msg.emergency_car_y;
    }
    else {
      resolved.emergency_car_y = 0.0
    }

    if (msg.emergency_car_is_near !== undefined) {
      resolved.emergency_car_is_near = msg.emergency_car_is_near;
    }
    else {
      resolved.emergency_car_is_near = 0
    }

    if (msg.terminal_jd !== undefined) {
      resolved.terminal_jd = msg.terminal_jd;
    }
    else {
      resolved.terminal_jd = 0.0
    }

    if (msg.terminal_wd !== undefined) {
      resolved.terminal_wd = msg.terminal_wd;
    }
    else {
      resolved.terminal_wd = 0.0
    }

    if (msg.terminal_x !== undefined) {
      resolved.terminal_x = msg.terminal_x;
    }
    else {
      resolved.terminal_x = 0.0
    }

    if (msg.terminal_y !== undefined) {
      resolved.terminal_y = msg.terminal_y;
    }
    else {
      resolved.terminal_y = 0.0
    }

    return resolved;
    }
};

module.exports = OBU_fusion;

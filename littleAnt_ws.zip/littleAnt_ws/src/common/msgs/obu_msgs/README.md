# obu_msgs

ROS package for obu messages

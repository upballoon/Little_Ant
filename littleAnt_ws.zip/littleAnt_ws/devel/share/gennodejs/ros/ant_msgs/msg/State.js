// Auto-generated. Do not edit!

// (in-package ant_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class State {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.act_gear = null;
      this.driverless_mode = null;
      this.hand_brake = null;
      this.emergency_brake = null;
      this.vehicle_ready = null;
      this.vehicle_speed = null;
      this.roadwheelAngle = null;
    }
    else {
      if (initObj.hasOwnProperty('act_gear')) {
        this.act_gear = initObj.act_gear
      }
      else {
        this.act_gear = 0;
      }
      if (initObj.hasOwnProperty('driverless_mode')) {
        this.driverless_mode = initObj.driverless_mode
      }
      else {
        this.driverless_mode = false;
      }
      if (initObj.hasOwnProperty('hand_brake')) {
        this.hand_brake = initObj.hand_brake
      }
      else {
        this.hand_brake = false;
      }
      if (initObj.hasOwnProperty('emergency_brake')) {
        this.emergency_brake = initObj.emergency_brake
      }
      else {
        this.emergency_brake = false;
      }
      if (initObj.hasOwnProperty('vehicle_ready')) {
        this.vehicle_ready = initObj.vehicle_ready
      }
      else {
        this.vehicle_ready = false;
      }
      if (initObj.hasOwnProperty('vehicle_speed')) {
        this.vehicle_speed = initObj.vehicle_speed
      }
      else {
        this.vehicle_speed = 0.0;
      }
      if (initObj.hasOwnProperty('roadwheelAngle')) {
        this.roadwheelAngle = initObj.roadwheelAngle
      }
      else {
        this.roadwheelAngle = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type State
    // Serialize message field [act_gear]
    bufferOffset = _serializer.uint8(obj.act_gear, buffer, bufferOffset);
    // Serialize message field [driverless_mode]
    bufferOffset = _serializer.bool(obj.driverless_mode, buffer, bufferOffset);
    // Serialize message field [hand_brake]
    bufferOffset = _serializer.bool(obj.hand_brake, buffer, bufferOffset);
    // Serialize message field [emergency_brake]
    bufferOffset = _serializer.bool(obj.emergency_brake, buffer, bufferOffset);
    // Serialize message field [vehicle_ready]
    bufferOffset = _serializer.bool(obj.vehicle_ready, buffer, bufferOffset);
    // Serialize message field [vehicle_speed]
    bufferOffset = _serializer.float32(obj.vehicle_speed, buffer, bufferOffset);
    // Serialize message field [roadwheelAngle]
    bufferOffset = _serializer.float32(obj.roadwheelAngle, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type State
    let len;
    let data = new State(null);
    // Deserialize message field [act_gear]
    data.act_gear = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [driverless_mode]
    data.driverless_mode = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [hand_brake]
    data.hand_brake = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [emergency_brake]
    data.emergency_brake = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [vehicle_ready]
    data.vehicle_ready = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [vehicle_speed]
    data.vehicle_speed = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [roadwheelAngle]
    data.roadwheelAngle = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ant_msgs/State';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f1a38b3da04b1f3968082c6789d689f7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message is the integration of four vehicle parts
    
    uint8 act_gear
    bool driverless_mode
    bool hand_brake
    bool emergency_brake
    bool vehicle_ready
    float32 vehicle_speed
    float32 roadwheelAngle
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new State(null);
    if (msg.act_gear !== undefined) {
      resolved.act_gear = msg.act_gear;
    }
    else {
      resolved.act_gear = 0
    }

    if (msg.driverless_mode !== undefined) {
      resolved.driverless_mode = msg.driverless_mode;
    }
    else {
      resolved.driverless_mode = false
    }

    if (msg.hand_brake !== undefined) {
      resolved.hand_brake = msg.hand_brake;
    }
    else {
      resolved.hand_brake = false
    }

    if (msg.emergency_brake !== undefined) {
      resolved.emergency_brake = msg.emergency_brake;
    }
    else {
      resolved.emergency_brake = false
    }

    if (msg.vehicle_ready !== undefined) {
      resolved.vehicle_ready = msg.vehicle_ready;
    }
    else {
      resolved.vehicle_ready = false
    }

    if (msg.vehicle_speed !== undefined) {
      resolved.vehicle_speed = msg.vehicle_speed;
    }
    else {
      resolved.vehicle_speed = 0.0
    }

    if (msg.roadwheelAngle !== undefined) {
      resolved.roadwheelAngle = msg.roadwheelAngle;
    }
    else {
      resolved.roadwheelAngle = 0.0
    }

    return resolved;
    }
};

module.exports = State;

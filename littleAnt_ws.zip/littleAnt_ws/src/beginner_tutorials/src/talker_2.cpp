#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <fstream>
#include <ant_msgs/ControlCmd2.h>
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <bits/stdc++.h>

using namespace std;

int data_length;
int data_index;
vector<float> res_speed;
ant_msgs::ControlCmd2 controlCmd_test;
std::mutex cmd_mutex;

void SplitString(const std::string& s, std::vector<float>& v, const std::string& c)
{
  std::string::size_type pos1, pos2;
  pos2 = s.find(c);
  pos1 = 0;
  while(std::string::npos != pos2)
  {
    string tmp = s.substr(pos1, pos2-pos1);
    v.push_back(atof(tmp.c_str()));
 
    pos1 = pos2 + c.size();
    pos2 = s.find(c, pos1);
  }
  if(pos1 != s.length())
    v.push_back(atof(s.substr(pos1).c_str()));
}

void cmd_callback(const ant_msgs::ControlCmd2& msg)
{
    cmd_mutex.lock();
    float pub_speed;
    
    if(data_index < data_length - 1)
    {
        pub_speed = res_speed[data_index] * 3.6;
        data_index++;
    }
    else
    {
        pub_speed = 0.0;
    }
    
    controlCmd_test = msg;
    controlCmd_test.set_speed = pub_speed;

    // std::cout << "data_index:" << data_index << std::endl; 
    // std::cout << "data_length:" << data_length << std::endl; 
    // std::cout << "pub_speed:" << pub_speed << std::endl; 
    std::cout << "controlCmd_test:" << controlCmd_test << std::endl;
    cmd_mutex.unlock();
    
}

int main(int argc, char **argv)
{
  ifstream data("/home/seu/Desktop/data/Exp_CS_Case4.csv"); 
  string line;
  vector<vector<string> > strArray;

  vector<float> res_time;
  
  int flag = 1;

  while (getline(data, line))
  {
    if (flag == 1) {
      SplitString(line, res_time, ",");
    }
    if (flag == 2) {
      SplitString(line, res_speed, ",");
    }
    flag++;
  }
  for (int i = 1; i <= 1500; ++i)
  {
    //res_speed.push_front(res_speed[1]);
    res_speed.insert(res_speed.begin(), res_speed[1]);
  }

  data_length = res_speed.size();
  std::cout << "data_length:" << data_length << std::endl; 
  data_index = 0;
  
  
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Subscriber sub_cmd_test;
  sub_cmd_test = n.subscribe("/controlCmd2", 1, &cmd_callback);
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("/chatter", 1000);
  ros::Publisher pub_cmd_test = n.advertise<ant_msgs::ControlCmd2>("/control_test", 1);
  ros::Rate loop_rate(100);

  
  while(ros::ok())
  {
    pub_cmd_test.publish(controlCmd_test);
    ros::spinOnce();
    loop_rate.sleep();
  }


  return 0;
}


"use strict";

let Light = require('./Light.js');

module.exports = {
  Light: Light,
};

#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <fstream>
#include <ant_msgs/ControlCmd2.h>
#include <iostream>
#include <string>
#include <vector>
#include <list>
#include <bits/stdc++.h>

using namespace std;

int data_length;
int data_index;
vector<float> res_speed;
ant_msgs::ControlCmd2 controlCmd_test;
std::mutex cmd_mutex;
ros::Publisher pub_cmd_test;

void SplitString(const std::string& s, std::vector<float>& v, const std::string& c)
{
  std::string::size_type pos1, pos2;
  pos2 = s.find(c);
  pos1 = 0;
  while(std::string::npos != pos2)
  {
    string tmp = s.substr(pos1, pos2-pos1);
    v.push_back(atof(tmp.c_str()));
 
    pos1 = pos2 + c.size();
    pos2 = s.find(c, pos1);
  }
  if(pos1 != s.length())
    v.push_back(atof(s.substr(pos1).c_str()));
}

void cmd_callback(const ant_msgs::ControlCmd2& msg)
{
    cmd_mutex.lock();
    float pub_speed;
    
    if(data_index < data_length - 1)
    {
        pub_speed = res_speed[data_index]*3.6;
        data_index++;
    }
    else
    {
        pub_speed = 0.0;
    }
    
    
    controlCmd_test = msg;
    controlCmd_test.set_speed = pub_speed;
    pub_cmd_test.publish(controlCmd_test);
    
    // std::cout << "pub_speed:" << pub_speed << std::endl; 
    std::cout << "controlCmd_test:" << controlCmd_test << std::endl;
    cmd_mutex.unlock();
    
}

int main(int argc, char **argv)
{
  ifstream data("/home/ding/桌面/Data/Exp_CS_Case1.csv"); 
  string line;
  vector<vector<string> > strArray;

  vector<float> res_time;
  
  int flag = 1;

  while (getline(data, line))
  {
    if (flag == 1) {
      SplitString(line, res_time, ",");
    }
    if (flag == 2) {
      SplitString(line, res_speed, ",");
    }
    flag++;
  }
  
  for (int i = 1; i <= 1000; ++i)
  {
    res_speed.push_back(res_speed[1]);
  }
  data_length = res_speed.size();
  data_index = 0;
  
    // for(int i = 0; i < res_time.size(); ++i) 
    // {
    //   cout << "Time: " << res_time[i] << endl;
    // }

    // for(int i = 0; i < res_speed.size(); ++i) 
    // {
    // cout << "Speed: " << res_speed[i] << endl;
    // }
  
  
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Subscriber sub_cmd_test;
  sub_cmd_test = n.subscribe("/controlCmd2", 1, &cmd_callback);
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  pub_cmd_test = n.advertise<ant_msgs::ControlCmd2>("control_test", 1);
  ros::Rate loop_rate(100);
  
  /*
  int count = 0;
  int i = 0;
  float pub_speed;
  while (ros::ok())
  {
    std_msgs::String msg;
    std::stringstream ss;
    ant_msgs::ControlCmd2 controlCmd_test;
    
    msg.data = ss.str();

    if (i *10 > res_speed.size())
    {
      pub_speed = 0;
    }
    else{
      pub_speed = res_speed[i];
    }

    controlCmd_test.set_speed = pub_speed;

    ROS_INFO("%s", msg.data.c_str());

    chatter_pub.publish(msg);
    pub_cmd_test.publish(controlCmd_test);
    

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
    ++i;
  }
  */
  
  ros::spin();
  return 0;
  while(ros::ok())
  {
    //pub_cmd_test.publish(controlCmd_test);
    ros::spinOnce();
    loop_rate.sleep();
  }


  return 0;
}

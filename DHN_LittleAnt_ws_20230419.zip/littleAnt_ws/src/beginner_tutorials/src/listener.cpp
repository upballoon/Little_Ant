#include "ros/ros.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "ant_msgs/State.h"
#include "ant_msgs/ControlCmd2.h"
#include "std_msgs/Float32MultiArray.h"

ros::Publisher pub_state;
ros::Publisher pub_sim_cmd;
float sim_speed = 0.0;

void chatterCallback(const ant_msgs::State::ConstPtr& msg)
{
  ROS_INFO("I heard: [%lf]", msg->vehicle_speed);
  std_msgs::Float32MultiArray state;
  state.data.resize(2);
  state.data[0] = msg->vehicle_speed;
  state.data[1] = msg->roadwheelAngle;

  pub_state.publish(state);
} 

void controlCmd22_callback(const ant_msgs::ControlCmd2::ConstPtr& msg)
{
  ant_msgs::ControlCmd2 cmd;
  cmd.set_gear = msg->set_gear;
  cmd.set_speed = sim_speed;
  cmd.set_brake = msg->set_brake;
  cmd.set_accelerate = msg->set_accelerate;
  cmd.set_roadWheelAngle = msg->set_roadWheelAngle;
  cmd.set_emergencyBrake = msg->set_emergencyBrake;
  
  pub_sim_cmd.publish(cmd);
}

void matlab_cmd_callback(const std_msgs::Float32::ConstPtr& msg)
{
  std::cout << "matlab_cmd" << std::endl;
  sim_speed = msg->data;
  
  
}

int main(int argc, char **argv)
{
  
  ros::init(argc, argv, "listener");
  ros::NodeHandle n; 
  
  ros::Subscriber sub_vehicle_state = n.subscribe("vehicleState", 1000, chatterCallback); 
  ros::Subscriber sub_matlab_cmd = n.subscribe("/matlab_cmd", 1000, matlab_cmd_callback); 
  ros::Subscriber sub_raw_cmd22 = n.subscribe("/controlCmd22", 1000, controlCmd22_callback); 

  pub_state = n.advertise<std_msgs::Float32MultiArray>("/matlab_state",1);
  pub_sim_cmd = n.advertise<ant_msgs::ControlCmd2>("/controlCmd2",1);

  ros::spin();

  return 0;
}

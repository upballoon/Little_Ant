#include "ros/ros.h"
#include "std_msgs/String.h"
#include <sstream>
#include <fstream>
#include <ant_msgs/ControlCmd2.h>
int main(int argc, char **argv)
{
  using namespace std;
  ifstream inFile("/home/ding/桌面/Data/Example.csv",ios::in);
  ros::init(argc, argv, "talker");
  ros::NodeHandle n;
  ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  ros::Publisher pub_cmd_test = n.advertise<ant_msgs::ControlCmd2>("control_test", 1);
  ros::Rate loop_rate(10);

  double a1[4] = {1.2, 2.4, 3.6, 4.8};
  

  int count = 0;
  int i = 0;
  while (ros::ok())
  {
    std_msgs::String msg;
    std::stringstream ss;
    ant_msgs::ControlCmd2 controlCmd_test;
    if (i >= 4)
       i = 0;

    // ss << "hello world " << count;
    ss << a1[i] << " " << count;
    msg.data = ss.str();
    controlCmd_test.set_speed = 2.0;

    ROS_INFO("%s", msg.data.c_str());

    chatter_pub.publish(msg);
    pub_cmd_test.publish(controlCmd_test);
    

    ros::spinOnce();

    loop_rate.sleep();
    ++count;
    ++i;
  }


  return 0;
}

// Auto-generated. Do not edit!

// (in-package gps_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Gpchc {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.GPSWeek = null;
      this.GPSTime = null;
      this.Heading = null;
      this.Pitch = null;
      this.Roll = null;
      this.gyro_x = null;
      this.gyro_y = null;
      this.gyro_z = null;
      this.acc_x = null;
      this.acc_y = null;
      this.acc_z = null;
      this.Lattitude = null;
      this.Longitude = null;
      this.Altitude = null;
      this.Ve = null;
      this.Vn = null;
      this.Vu = null;
      this.Baseline = null;
      this.NSV1 = null;
      this.NSV2 = null;
      this.Status = null;
      this.Age = null;
      this.Warming = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('GPSWeek')) {
        this.GPSWeek = initObj.GPSWeek
      }
      else {
        this.GPSWeek = 0;
      }
      if (initObj.hasOwnProperty('GPSTime')) {
        this.GPSTime = initObj.GPSTime
      }
      else {
        this.GPSTime = 0.0;
      }
      if (initObj.hasOwnProperty('Heading')) {
        this.Heading = initObj.Heading
      }
      else {
        this.Heading = 0.0;
      }
      if (initObj.hasOwnProperty('Pitch')) {
        this.Pitch = initObj.Pitch
      }
      else {
        this.Pitch = 0.0;
      }
      if (initObj.hasOwnProperty('Roll')) {
        this.Roll = initObj.Roll
      }
      else {
        this.Roll = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_x')) {
        this.gyro_x = initObj.gyro_x
      }
      else {
        this.gyro_x = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_y')) {
        this.gyro_y = initObj.gyro_y
      }
      else {
        this.gyro_y = 0.0;
      }
      if (initObj.hasOwnProperty('gyro_z')) {
        this.gyro_z = initObj.gyro_z
      }
      else {
        this.gyro_z = 0.0;
      }
      if (initObj.hasOwnProperty('acc_x')) {
        this.acc_x = initObj.acc_x
      }
      else {
        this.acc_x = 0.0;
      }
      if (initObj.hasOwnProperty('acc_y')) {
        this.acc_y = initObj.acc_y
      }
      else {
        this.acc_y = 0.0;
      }
      if (initObj.hasOwnProperty('acc_z')) {
        this.acc_z = initObj.acc_z
      }
      else {
        this.acc_z = 0.0;
      }
      if (initObj.hasOwnProperty('Lattitude')) {
        this.Lattitude = initObj.Lattitude
      }
      else {
        this.Lattitude = 0.0;
      }
      if (initObj.hasOwnProperty('Longitude')) {
        this.Longitude = initObj.Longitude
      }
      else {
        this.Longitude = 0.0;
      }
      if (initObj.hasOwnProperty('Altitude')) {
        this.Altitude = initObj.Altitude
      }
      else {
        this.Altitude = 0.0;
      }
      if (initObj.hasOwnProperty('Ve')) {
        this.Ve = initObj.Ve
      }
      else {
        this.Ve = 0.0;
      }
      if (initObj.hasOwnProperty('Vn')) {
        this.Vn = initObj.Vn
      }
      else {
        this.Vn = 0.0;
      }
      if (initObj.hasOwnProperty('Vu')) {
        this.Vu = initObj.Vu
      }
      else {
        this.Vu = 0.0;
      }
      if (initObj.hasOwnProperty('Baseline')) {
        this.Baseline = initObj.Baseline
      }
      else {
        this.Baseline = 0.0;
      }
      if (initObj.hasOwnProperty('NSV1')) {
        this.NSV1 = initObj.NSV1
      }
      else {
        this.NSV1 = 0;
      }
      if (initObj.hasOwnProperty('NSV2')) {
        this.NSV2 = initObj.NSV2
      }
      else {
        this.NSV2 = 0;
      }
      if (initObj.hasOwnProperty('Status')) {
        this.Status = initObj.Status
      }
      else {
        this.Status = 0;
      }
      if (initObj.hasOwnProperty('Age')) {
        this.Age = initObj.Age
      }
      else {
        this.Age = 0;
      }
      if (initObj.hasOwnProperty('Warming')) {
        this.Warming = initObj.Warming
      }
      else {
        this.Warming = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Gpchc
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [GPSWeek]
    bufferOffset = _serializer.uint32(obj.GPSWeek, buffer, bufferOffset);
    // Serialize message field [GPSTime]
    bufferOffset = _serializer.float64(obj.GPSTime, buffer, bufferOffset);
    // Serialize message field [Heading]
    bufferOffset = _serializer.float32(obj.Heading, buffer, bufferOffset);
    // Serialize message field [Pitch]
    bufferOffset = _serializer.float32(obj.Pitch, buffer, bufferOffset);
    // Serialize message field [Roll]
    bufferOffset = _serializer.float32(obj.Roll, buffer, bufferOffset);
    // Serialize message field [gyro_x]
    bufferOffset = _serializer.float32(obj.gyro_x, buffer, bufferOffset);
    // Serialize message field [gyro_y]
    bufferOffset = _serializer.float32(obj.gyro_y, buffer, bufferOffset);
    // Serialize message field [gyro_z]
    bufferOffset = _serializer.float32(obj.gyro_z, buffer, bufferOffset);
    // Serialize message field [acc_x]
    bufferOffset = _serializer.float32(obj.acc_x, buffer, bufferOffset);
    // Serialize message field [acc_y]
    bufferOffset = _serializer.float32(obj.acc_y, buffer, bufferOffset);
    // Serialize message field [acc_z]
    bufferOffset = _serializer.float32(obj.acc_z, buffer, bufferOffset);
    // Serialize message field [Lattitude]
    bufferOffset = _serializer.float64(obj.Lattitude, buffer, bufferOffset);
    // Serialize message field [Longitude]
    bufferOffset = _serializer.float64(obj.Longitude, buffer, bufferOffset);
    // Serialize message field [Altitude]
    bufferOffset = _serializer.float32(obj.Altitude, buffer, bufferOffset);
    // Serialize message field [Ve]
    bufferOffset = _serializer.float32(obj.Ve, buffer, bufferOffset);
    // Serialize message field [Vn]
    bufferOffset = _serializer.float32(obj.Vn, buffer, bufferOffset);
    // Serialize message field [Vu]
    bufferOffset = _serializer.float32(obj.Vu, buffer, bufferOffset);
    // Serialize message field [Baseline]
    bufferOffset = _serializer.float32(obj.Baseline, buffer, bufferOffset);
    // Serialize message field [NSV1]
    bufferOffset = _serializer.uint32(obj.NSV1, buffer, bufferOffset);
    // Serialize message field [NSV2]
    bufferOffset = _serializer.uint32(obj.NSV2, buffer, bufferOffset);
    // Serialize message field [Status]
    bufferOffset = _serializer.uint8(obj.Status, buffer, bufferOffset);
    // Serialize message field [Age]
    bufferOffset = _serializer.uint32(obj.Age, buffer, bufferOffset);
    // Serialize message field [Warming]
    bufferOffset = _serializer.uint8(obj.Warming, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Gpchc
    let len;
    let data = new Gpchc(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [GPSWeek]
    data.GPSWeek = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [GPSTime]
    data.GPSTime = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [Heading]
    data.Heading = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Pitch]
    data.Pitch = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Roll]
    data.Roll = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gyro_x]
    data.gyro_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gyro_y]
    data.gyro_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gyro_z]
    data.gyro_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acc_x]
    data.acc_x = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acc_y]
    data.acc_y = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acc_z]
    data.acc_z = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Lattitude]
    data.Lattitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [Longitude]
    data.Longitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [Altitude]
    data.Altitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Ve]
    data.Ve = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Vn]
    data.Vn = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Vu]
    data.Vu = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [Baseline]
    data.Baseline = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [NSV1]
    data.NSV1 = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [NSV2]
    data.NSV2 = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [Status]
    data.Status = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [Age]
    data.Age = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [Warming]
    data.Warming = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 98;
  }

  static datatype() {
    // Returns string type for a message object
    return 'gps_msgs/Gpchc';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9f18256823037b186a8119103374f006';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    
    uint32 GPSWeek
    float64 GPSTime
    
    float32 Heading
    float32 Pitch
    float32 Roll
    
    float32 gyro_x
    float32 gyro_y
    float32 gyro_z
    
    float32 acc_x
    float32 acc_y
    float32 acc_z
    
    float64 Lattitude
    float64 Longitude
    float32 Altitude
    
    float32 Ve
    float32 Vn
    float32 Vu
    
    float32 Baseline
    uint32 NSV1
    uint32 NSV2
    
    uint8 Status
    uint32 Age
    uint8 Warming
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Gpchc(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.GPSWeek !== undefined) {
      resolved.GPSWeek = msg.GPSWeek;
    }
    else {
      resolved.GPSWeek = 0
    }

    if (msg.GPSTime !== undefined) {
      resolved.GPSTime = msg.GPSTime;
    }
    else {
      resolved.GPSTime = 0.0
    }

    if (msg.Heading !== undefined) {
      resolved.Heading = msg.Heading;
    }
    else {
      resolved.Heading = 0.0
    }

    if (msg.Pitch !== undefined) {
      resolved.Pitch = msg.Pitch;
    }
    else {
      resolved.Pitch = 0.0
    }

    if (msg.Roll !== undefined) {
      resolved.Roll = msg.Roll;
    }
    else {
      resolved.Roll = 0.0
    }

    if (msg.gyro_x !== undefined) {
      resolved.gyro_x = msg.gyro_x;
    }
    else {
      resolved.gyro_x = 0.0
    }

    if (msg.gyro_y !== undefined) {
      resolved.gyro_y = msg.gyro_y;
    }
    else {
      resolved.gyro_y = 0.0
    }

    if (msg.gyro_z !== undefined) {
      resolved.gyro_z = msg.gyro_z;
    }
    else {
      resolved.gyro_z = 0.0
    }

    if (msg.acc_x !== undefined) {
      resolved.acc_x = msg.acc_x;
    }
    else {
      resolved.acc_x = 0.0
    }

    if (msg.acc_y !== undefined) {
      resolved.acc_y = msg.acc_y;
    }
    else {
      resolved.acc_y = 0.0
    }

    if (msg.acc_z !== undefined) {
      resolved.acc_z = msg.acc_z;
    }
    else {
      resolved.acc_z = 0.0
    }

    if (msg.Lattitude !== undefined) {
      resolved.Lattitude = msg.Lattitude;
    }
    else {
      resolved.Lattitude = 0.0
    }

    if (msg.Longitude !== undefined) {
      resolved.Longitude = msg.Longitude;
    }
    else {
      resolved.Longitude = 0.0
    }

    if (msg.Altitude !== undefined) {
      resolved.Altitude = msg.Altitude;
    }
    else {
      resolved.Altitude = 0.0
    }

    if (msg.Ve !== undefined) {
      resolved.Ve = msg.Ve;
    }
    else {
      resolved.Ve = 0.0
    }

    if (msg.Vn !== undefined) {
      resolved.Vn = msg.Vn;
    }
    else {
      resolved.Vn = 0.0
    }

    if (msg.Vu !== undefined) {
      resolved.Vu = msg.Vu;
    }
    else {
      resolved.Vu = 0.0
    }

    if (msg.Baseline !== undefined) {
      resolved.Baseline = msg.Baseline;
    }
    else {
      resolved.Baseline = 0.0
    }

    if (msg.NSV1 !== undefined) {
      resolved.NSV1 = msg.NSV1;
    }
    else {
      resolved.NSV1 = 0
    }

    if (msg.NSV2 !== undefined) {
      resolved.NSV2 = msg.NSV2;
    }
    else {
      resolved.NSV2 = 0
    }

    if (msg.Status !== undefined) {
      resolved.Status = msg.Status;
    }
    else {
      resolved.Status = 0
    }

    if (msg.Age !== undefined) {
      resolved.Age = msg.Age;
    }
    else {
      resolved.Age = 0
    }

    if (msg.Warming !== undefined) {
      resolved.Warming = msg.Warming;
    }
    else {
      resolved.Warming = 0
    }

    return resolved;
    }
};

module.exports = Gpchc;

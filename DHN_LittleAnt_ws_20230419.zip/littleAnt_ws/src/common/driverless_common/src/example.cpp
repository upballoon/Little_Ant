#include <driverless_common/structs.h>

int main()
{
    ControlCmd cmd;
    cmd.display("Example");
    ParkingPoint pp;
    return 0;
}
